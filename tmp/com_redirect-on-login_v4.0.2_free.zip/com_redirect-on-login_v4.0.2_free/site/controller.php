<?php
/**
* @package Redirect-On-Login (com_redirectonlogin)
* @version 4.0.2
* @copyright Copyright (C) 2008 - 2016 Carsten Engel. All rights reserved.
* @license GPL versions free/trial/pro
* @author http://www.pages-and-items.com
* @joomla Joomla is Free Software
*/


// no direct access
defined('_JEXEC') or die('Restricted access');


jimport('joomla.application.component.controller');


class redirectonloginController extends JControllerLegacy{
	
	function __construct(){			
		parent::__construct();			
	}
	
}
?>