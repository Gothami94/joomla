<?php
/**
* @package Redirect-On-Login (com_redirectonlogin)
* @version 4.0.2
* @copyright Copyright (C) 2008 - 2016 Carsten Engel. All rights reserved.
* @license GPL versions free/trial/pro
* @author http://www.pages-and-items.com
* @joomla Joomla is Free Software
*/


// no direct access
defined('_JEXEC') or die('Restricted access');

//no output here
//this thing is just a view so that admin users can make a link in the menu-manager to logout

?>